print('Hello', end='')
print('Hello')
print('Hello')

s = input() # 문자열형으로 받음
s = eval(s) # 숫자로 변환
print(s)
print("======================")
# swap
a,b = 10, 20
print(a, b)
a,b = b,a
print(a, b)
print("======================")

print(3 / 2)
print(3 // 2)
print(3 ** 2)
print(3 % 2)
print("======================")

a, b = 3, 2
a *= b
print(a)
a **= b
print(a)
a /= b
print(a)
a //= b
print(a)
a %= b
print(a)
