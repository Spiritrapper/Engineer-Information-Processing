import java.util.*;
import java.lang.*;
import java.io.*;

class Main {
    public static void main(String[] args) {
        String str = "Power overwhelming";
        System.out.printf("%8.4s", str);
        //     Powe
    }
}
