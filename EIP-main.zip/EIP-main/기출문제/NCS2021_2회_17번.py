a = [1, 3, 5, 7]
a.insert(3,4) # a[3]에 4 대입
a.remove(3) # a에서 값이 3인것 앞에서부터 1개 제거
print(a[0:4])
